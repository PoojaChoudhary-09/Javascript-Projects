const btn =document.getElementById('searchBtn')
const cityName =document.getElementById('cityName')
const API_Key = '62644b64d1c37c49dae774ec7af4cac5'

async function fetchData(city){
    try{
        cityName.value='';
        console.log("city name", city);
        let res = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_Key}&units=metric`)
        let result = await res.json();
        if(result.message){
            document.getElementById("secondDiv").innerHTML = `<h1>${result.message}</h1>`
        }
     //    console.log(result)
        displayWeather(result);
    }catch(err){
        console.log(err.message)
    }
   
}

async function fetchDataByCoordinates(lati, longi){
    try{
        console.log(lati, longi);
        let res = await fetch(`https://api.openweathermap.org/data/2.5/weather?lati=${lati}&lon=${longi}&appid=${API_Key}&units=metric`)
        let result = await res.json();
        if(result.message){
            document.getElementById("secondDiv").innerHTML = `<h1>${result.message}</h1>`
        }
        // console.log(result)
        displayWeather(result);
    }catch(err){
        console.log(err.message);
    }
   
}

btn.addEventListener('click', ()=>{
    fetchData(cityName.value)
})

function displayWeather({name,main, wind,weather}){
    div = ` <div id="weatherInfo">
                <p id="temp">${main.temp}&deg;C</p>
                <p>${weather[0].description}</p>
                <img src = 'https://openweathermap.org/img/w/${weather[0].icon}.png'>
                <p id="city">${name}</p>
            </div>
            <div class="otherInfo">
                <div class="wind">
                    <p>Wind</p>
                    <p>${wind.speed}m/s</p>
                </div>
                <div class="wind">
                    <p>Pressure</p>
                    <p>${main.pressure}ma</p>
                </div>
                <div class="wind">
                    <p>Humidity</p>
                    <p>${main.humidity}</p>
                </div>
            </div>`
 document.getElementById('secondDiv').innerHTML = div
}

document.getElementById('currLoc').addEventListener('click',()=>{
    navigator.geolocation.getCurrentPosition((position) => {
    let lati = position.coords.latitude
    let longi = position.coords.longitude
    fetchDataByCoordinates(lati,longi)
    })
});