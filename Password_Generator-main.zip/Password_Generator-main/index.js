const btn = document.getElementById('btn');
const newpass = document.getElementById("newpass")
const slider = document.getElementById("range");
const rangeVal = document.getElementById("rangeVal")

const upperCase = document.getElementById("capLet");
const lowerCase = document.getElementById("lowLet");
const number = document.getElementById("number");
const specialChar = document.getElementById("symbol");
const copybtn = document.getElementById("copybtn");

rangeVal.innerText = slider.value

slider.addEventListener('input', (e) => {
    rangeVal.innerText = e.target.value
})

btn.addEventListener('click', () => {
    let capitalLetter = `ABCDEFGHIJKLMNOPQRSTUVWXYZ`
    let smallLetter = 'abcdefghijklmnopqrstuvwxyz'
    let numberStr = '0123456789'
    let symbolStr = '~!@#$%^&*()_+{}'
    let finalStr = '';
    if (upperCase.checked) {
        finalStr = finalStr + capitalLetter
    }
    if (lowerCase.checked) {
        finalStr += smallLetter
    }
    if (number.checked) {
        finalStr += numberStr
    }
    if (specialChar.checked) {
        finalStr += symbolStr
    }
    if (finalStr == '') {
        alert("please select atleast one field")
    }
    let latestPass = ''

    for (let i = 0; i < slider.value; i++) {
        let random = Math.floor(Math.random() * finalStr.length)
        latestPass += finalStr[random]
        // latestPass += finalStr.charAt(random) ----same as above line
    }

    newpass.innerText = `${latestPass}`


})
copybtn.addEventListener('click', () => {
    navigator.clipboard.writeText(newpass.innerText);
})