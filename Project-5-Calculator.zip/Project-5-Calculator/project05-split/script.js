/* ── SECTION 1: TAB SWITCHING ── */
const allTabIds = ['si', 'bm', 'ca'];
const activeTabClass = { si: 'active-si', bm: 'active-bm', ca: 'active-ca' };

function switchTab(tabId) {
  for (let i = 0; i < allTabIds.length; i++) {
    const currentTabId = allTabIds[i];
    document.getElementById('panel-' + currentTabId).classList.remove('active');
    const tabButton = document.getElementById('tab-' + currentTabId);
    tabButton.classList.remove('active-si', 'active-bm', 'active-ca');
  }
  document.getElementById('panel-' + tabId).classList.add('active');
  document.getElementById('tab-' + tabId).classList.add(activeTabClass[tabId]);
}


/* ── SECTION 2: HELPER FUNCTIONS ── */
function getElement(elementId) {
  return document.getElementById(elementId);
}

function formatNumber(number, decimalPlaces = 0) {
  return number.toLocaleString('en-IN', {
    minimumFractionDigits: decimalPlaces,
    maximumFractionDigits: decimalPlaces
  });
}

function showError(inputId, errorId, errorText) {
  const inputField = getElement(inputId);
  const errorDiv = getElement(errorId);
  if (inputField) inputField.classList.add('has-error');
  if (errorDiv) errorDiv.textContent = errorText;
}

function clearError(inputId, errorId) {
  const inputField = getElement(inputId);
  const errorDiv = getElement(errorId);
  if (inputField) inputField.classList.remove('has-error');
  if (errorDiv) errorDiv.textContent = '';
}


/* ── SECTION 3: SIMPLE INTEREST CALCULATOR (SI = P×R×T / 100) ── */
function validateSimpleInterest() {
  const principal = parseFloat(getElement('si-principal').value);
  const rate = parseFloat(getElement('si-rate').value);
  const time = parseFloat(getElement('si-time').value);
  let isValid = true;

  if (!principal || principal <= 0) {
    showError('si-principal', 'err-si-principal', 'Enter a valid principal amount');
    isValid = false;
  } else {
    clearError('si-principal', 'err-si-principal');
  }

  if (isNaN(rate) || rate < 0 || rate > 100) {
    showError('si-rate', 'err-si-rate', 'Rate must be between 0 and 100');
    isValid = false;
  } else {
    clearError('si-rate', 'err-si-rate');
  }

  if (!time || time <= 0) {
    showError('si-time', 'err-si-time', 'Enter a valid time period in years');
    isValid = false;
  } else {
    clearError('si-time', 'err-si-time');
  }

  return isValid ? { principal, rate, time } : null;
}

function calculateSimpleInterest() {
  const inputValues = validateSimpleInterest();
  if (inputValues === null) return;

  const { principal, rate, time } = inputValues;
  const simpleInterest = (principal * rate * time) / 100;
  const totalAmount = principal + simpleInterest;
  const returnPercent = (simpleInterest / principal) * 100;
  const totalMonths = time * 12;
  const monthlyIncome = simpleInterest / totalMonths;

  getElement('display-si-interest').textContent = '₹' + formatNumber(simpleInterest);
  getElement('display-si-total').textContent = '₹' + formatNumber(totalAmount);
  getElement('display-si-percent').textContent = formatNumber(returnPercent, 2) + '%';
  getElement('display-si-years').textContent = 'over ' + time + ' year' + (time !== 1 ? 's' : '');
  getElement('display-si-monthly').textContent = '₹' + formatNumber(monthlyIncome);

  getElement('result-si').classList.add('show');
}

function resetSimpleInterest() {
  getElement('si-principal').value = '';
  getElement('si-rate').value = '';
  getElement('si-time').value = '';
  clearError('si-principal', 'err-si-principal');
  clearError('si-rate', 'err-si-rate');
  clearError('si-time', 'err-si-time');
  getElement('result-si').classList.remove('show');
}


/* ── SECTION 4: BMI CALCULATOR (BMI = weight / height² in meters) ── */
const bmiCategories = [
  { maxBmi: 18.5, label: 'Underweight', color: '#5b8fff', bgColor: 'rgba(91,143,255,0.15)' },
  { maxBmi: 25, label: 'Normal weight', color: '#00d4a0', bgColor: 'rgba(0,212,160,0.15)' },
  { maxBmi: 30, label: 'Overweight', color: '#f5c518', bgColor: 'rgba(245,197,24,0.15)' },
  { maxBmi: 999, label: 'Obese', color: '#e03a3a', bgColor: 'rgba(224,58,58,0.15)' }
];

function getBmiCategory(bmiValue) {
  for (let i = 0; i < bmiCategories.length; i++) {
    if (bmiValue < bmiCategories[i].maxBmi) return bmiCategories[i];
  }
}

function getBmiNeedlePosition(bmiValue) {
  const barMinBmi = 10;
  const barMaxBmi = 45;
  let percentage = ((bmiValue - barMinBmi) / (barMaxBmi - barMinBmi)) * 100;
  if (percentage < 0) percentage = 0;
  if (percentage > 100) percentage = 100;
  return percentage;
}

function validateBMI() {
  const height = parseFloat(getElement('bmi-height').value);
  const weight = parseFloat(getElement('bmi-weight').value);
  let isValid = true;

  if (!height || height < 50 || height > 250) {
    showError('bmi-height', 'err-bmi-height', 'Enter height between 50 and 250 cm');
    isValid = false;
  } else {
    clearError('bmi-height', 'err-bmi-height');
  }

  if (!weight || weight < 10 || weight > 500) {
    showError('bmi-weight', 'err-bmi-weight', 'Enter weight between 10 and 500 kg');
    isValid = false;
  } else {
    clearError('bmi-weight', 'err-bmi-weight');
  }

  return isValid ? { height, weight } : null;
}

function calculateBMI() {
  const inputValues = validateBMI();
  if (inputValues === null) return;

  const { height: heightInCm, weight: weightInKg } = inputValues;
  const heightInMeters = heightInCm / 100;
  const bmiValue = weightInKg / (heightInMeters * heightInMeters);
  const category = getBmiCategory(bmiValue);
  const idealWeightLow = 18.5 * heightInMeters * heightInMeters;
  const idealWeightHigh = 24.9 * heightInMeters * heightInMeters;

  getElement('display-bmi-value').textContent = formatNumber(bmiValue, 1);
  getElement('display-bmi-ideal').textContent =
    formatNumber(idealWeightLow, 1) + '–' + formatNumber(idealWeightHigh, 1) + ' kg';

  const categoryDiv = getElement('display-bmi-category');
  categoryDiv.innerHTML =
    '<span class="bmi-category-pill" style="background:' + category.bgColor + '; color:' + category.color + ';">' +
    category.label + '</span>';

  getElement('bmi-needle').style.left = getBmiNeedlePosition(bmiValue) + '%';
  getElement('result-bmi').classList.add('show');
}

function resetBMI() {
  getElement('bmi-height').value = '';
  getElement('bmi-weight').value = '';
  clearError('bmi-height', 'err-bmi-height');
  clearError('bmi-weight', 'err-bmi-weight');
  getElement('result-bmi').classList.remove('show');
  getElement('bmi-needle').style.left = '0%';
  getElement('display-bmi-category').innerHTML = '';
}


/* ── SECTION 5: CALORIE CALCULATOR (Mifflin-St Jeor: BMR then TDEE = BMR × activity) ── */
let selectedGender = 'male';

function setGender(gender) {
  selectedGender = gender;
  if (gender === 'male') {
    getElement('btn-male').classList.add('active-gender');
    getElement('btn-female').classList.remove('active-gender');
  } else {
    getElement('btn-female').classList.add('active-gender');
    getElement('btn-male').classList.remove('active-gender');
  }
}

function validateCalories() {
  const age = parseFloat(getElement('cal-age').value);
  const weight = parseFloat(getElement('cal-weight').value);
  const height = parseFloat(getElement('cal-height').value);
  let isValid = true;

  if (!age || age < 1 || age > 120) {
    showError('cal-age', 'err-cal-age', 'Enter age between 1 and 120');
    isValid = false;
  } else {
    clearError('cal-age', 'err-cal-age');
  }

  if (!weight || weight < 10 || weight > 500) {
    showError('cal-weight', 'err-cal-weight', 'Enter weight between 10 and 500 kg');
    isValid = false;
  } else {
    clearError('cal-weight', 'err-cal-weight');
  }

  if (!height || height < 50 || height > 250) {
    showError('cal-height', 'err-cal-height', 'Enter height between 50 and 250 cm');
    isValid = false;
  } else {
    clearError('cal-height', 'err-cal-height');
  }

  return isValid ? { age, weight, height } : null;
}

function calculateCalories() {
  const inputValues = validateCalories();
  if (inputValues === null) return;

  const { age, weight, height } = inputValues;
  const activityFactor = parseFloat(getElement('cal-activity').value);

  const bmrValue = selectedGender === 'male'
    ? (10 * weight) + (6.25 * height) - (5 * age) + 5
    : (10 * weight) + (6.25 * height) - (5 * age) - 161;

  const tdeeValue = bmrValue * activityFactor;
  const weightLossCalories = tdeeValue - 500;
  const weightGainCalories = tdeeValue + 500;

  getElement('display-cal-bmr').textContent = formatNumber(bmrValue) + ' kcal';
  getElement('display-cal-tdee').textContent = formatNumber(tdeeValue) + ' kcal';
  getElement('display-cal-loss').textContent = formatNumber(weightLossCalories) + ' kcal';
  getElement('display-cal-gain').textContent = formatNumber(weightGainCalories) + ' kcal';

  getElement('result-cal').classList.add('show');
}

function resetCalories() {
  getElement('cal-age').value = '';
  getElement('cal-weight').value = '';
  getElement('cal-height').value = '';
  getElement('cal-activity').value = '1.55';
  setGender('male');
  clearError('cal-age', 'err-cal-age');
  clearError('cal-weight', 'err-cal-weight');
  clearError('cal-height', 'err-cal-height');
  getElement('result-cal').classList.remove('show');
}
